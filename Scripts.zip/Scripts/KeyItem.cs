﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyItem : InteractionObject
{
    public override void Interact(Inventory inventory)
    {
        print(typeof(KeyItem));
        print("Key interaction!");
        inventory.AddItem(this.gameObject);
    }
}
