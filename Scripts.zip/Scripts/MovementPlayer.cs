﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MovementPlayer : MonoBehaviour
{
    Animator anim;
    public bool Sprint = false;
    public Text StaminaText;
    public float walkSpeed = 5f;
    float currentstamina;
    bool WalkSpeed = true;
    public float SprintSpeed = 8f;
    public Slider StaminaSlider;
    public int addStamina = 1;


    public float Stamina = 10;

    public Rigidbody2D Rb2d;
    public float maxStamina = 10f;

    void Start()
    {
        Rb2d = GetComponent<Rigidbody2D>();
        Stamina = maxStamina;
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        uppdateStamina();
        currentstamina = Stamina;

    }

    private void FixedUpdate()
    {

        if (Input.GetKeyDown(KeyCode.W))
        {
            anim.SetInteger("State", 1);
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            anim.SetInteger("State", 2);
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
			anim.SetInteger("State", 3);
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
			anim.SetInteger("State", 4);
        }

        Vector2 input = new Vector2();

        input.x = Input.GetAxisRaw("Horizontal");

        input.y = Input.GetAxisRaw("Vertical");



        // if(a == b)
        // { a = c } else a = b


        //transform.Translate(input.normalized * Time.deltaTime * speed);

        if (Input.GetKey(KeyCode.LeftShift) && Stamina > 0)
        {
            Sprint = true;
            WalkSpeed = false;
            Staminabar();
        }
        else if (!Input.GetKey(KeyCode.LeftShift))
        {
            Sprint = false;
            WalkSpeed = true;
            RegenerateStamina();
            StaminaSlider.value = currentstamina;
        }
        float speed = Sprint == true ? SprintSpeed : walkSpeed;
        Rb2d.MovePosition((Vector2)transform.position + input * speed * 0.01f); //+ input före * 0.01f
    }

    public void Staminabar()
    {

        if (Sprint == true)
        {
            Stamina -= 1 * Time.deltaTime;
            StaminaSlider.value = currentstamina;
        }

        if (Stamina <= 0)
        {
            Sprint = false;
            WalkSpeed = true;
        }
    }

    public void RegenerateStamina()
    {
        if (Stamina <= maxStamina)
        {
            Stamina += addStamina * Time.deltaTime;
        }
    }

    public void uppdateStamina()
    {
        StaminaText.text = Stamina.ToString("f1") + "/Stamina";
    }

}
