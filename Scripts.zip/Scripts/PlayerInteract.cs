﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInteract : MonoBehaviour
{
    public Inventory inventory;
    public GameObject interaction;

    void Update()
    {
        if (Input.GetButtonDown("Interact") && interaction)
        {
            interaction.GetComponent<InteractionObject>().Interact(inventory);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("InterObject"))
        {
            interaction = other.gameObject;
            Debug.Log(other.name);
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("InterObject"))
        {
            if (other.gameObject == interaction)
            {
                interaction = null;
            }
        }
    }
}

