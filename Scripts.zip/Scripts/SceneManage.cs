﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class SceneManage : MonoBehaviour
{

    public void Menu()
    {
        SceneManager.LoadScene("Menu");
    }
    public void Options()
    {
        SceneManager.LoadScene("Options");
    }
    public void GameOver()
    {
        SceneManager.LoadScene("GameOver");
    }
    public void Credits()
    {
        SceneManager.LoadScene("credscene");
    }
    public void PsychoPath()
    {
        SceneManager.LoadScene("Psycho-Path Colins Escape part 1");

    }
    public void QUIT()
    {
        Application.Quit();
    }
}