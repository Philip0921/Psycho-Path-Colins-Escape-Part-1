﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthPotion : InteractionObject
{
    public override void Interact(Inventory inventory)
    {
        print(typeof(HealthPotion));
        print("Health interaction!");
        inventory.AddItem(this.gameObject);
    }

    public override void Use()
    {
        GameObject.FindWithTag("Player").GetComponent<Health>().AddHP();
        
    }

}
