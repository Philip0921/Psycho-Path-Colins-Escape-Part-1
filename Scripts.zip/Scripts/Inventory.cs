﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Inventory : MonoBehaviour
{
    public GameObject gameManager;
    public int selectedID;
    private bool paused = false;
    public GameObject InventoryMenu;
    public GameObject[] inventory = new GameObject[15];
    public Button[] InventoryButtons = new Button[15];
    public string[] Item = new string[5];

    void Start()
    {
        InventoryMenu.SetActive(false);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.I))
        {
            paused = !paused;
        }

        if (paused)
        {
            InventoryMenu.SetActive(true);
            Time.timeScale = 0;
        }

        if (!paused)
        {
            InventoryMenu.SetActive(false);
            Time.timeScale = 1;
        }

    }

    public void AddItem(GameObject item)
    {

        bool itemAdded = false;


        for (int i = 0; i < inventory.Length; i++)
        {
            if (inventory[i] == null)
            {
                inventory[i] = item;
                //Update UI
                InventoryButtons[i].image.overrideSprite = item.GetComponent<SpriteRenderer>().sprite;
                Debug.Log(item.name + " was added");
                itemAdded = true;
                item.SendMessage("DoInteraction");
                break;
            }
        }

        //invetroy was full.
        if (!itemAdded)
        {
            Debug.Log("Invetroy Full - Item Not Added");
        }
    }

    public GameObject FindSpecificItem(string name)
    {
        for (int i = 0; i < inventory.Length; i++)
        {
            if (inventory[i].name == name)
                return inventory[i];
        }
        return null;
    }

    public bool FindItem(GameObject item)
    {
        if (item == null)
        {
            Debug.LogWarning("Tried comparing null object");
            return false;
        }

        for (int i = 0; i < inventory.Length; i++)
        {
            if (inventory[i] == item)
            {
                //We found the Item.
                return true;
            }
        }
        //Item not found.
        return false;
    }

    public void RemoveItem(GameObject item)
    {
        if (item == true)
        {
            for (int i = 0; i < inventory.Length; i++)
            {
                GameObject go = inventory[i];
                if (go == item)
                {
                    go.SetActive(true);
                    go.transform.position = transform.position;
                    //We found the item - Remove it.
                    go = null;
                    inventory[i] = null;
                    Debug.Log(item.name + " was removed from inventory");
                    //Update UI
                    InventoryButtons[i].image.overrideSprite = null;

                    Debug.Log("Done");
                    break;
                }
            }
        }
    }
    public void DropItem()
    {
        GameObject go = inventory[selectedID];
        go.SetActive(true);
        go.transform.position = transform.position;
        //We found the item - Remove it.
        go = null;
        inventory[selectedID] = null;
        Debug.Log(" was removed from inventory");
        //Update UI
        InventoryButtons[selectedID].image.overrideSprite = null;


    }

    public void UseItem()
    {
        GameObject go = inventory[selectedID];
        go.GetComponent<InteractionObject>().Use();
        inventory[selectedID] = null;
        Debug.Log(" Item was used!");
        //Update UI
        InventoryButtons[selectedID].image.overrideSprite = null;
        Destroy(go);
        go = null;
    }
}
