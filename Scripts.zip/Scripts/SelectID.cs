﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectID : MonoBehaviour
{
    private Inventory inv;

    private void Start()
    {
        inv = GameObject.FindWithTag("Player").GetComponent<Inventory>();
    }

    public void Select(int id)
    {
        inv.selectedID = id;
    }
}
