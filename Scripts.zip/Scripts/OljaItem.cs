﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OljaItem : InteractionObject {

    public override void Interact(Inventory inventory)
    {
        print(typeof(OljaItem));
        print("Olje interaction!");
        inventory.AddItem(this.gameObject);
    }
}
