﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum AIState
{
    Patrolling,
    Chasing,
    LostPlayer,

}
public class AIController : MonoBehaviour
{

    public Transform[] patrolPoints;
    public float speed;
    public float radius = 0.16f;

    [Range(0, 20f)]
    public float chaseDist;
    [Range(0, 20f)]
    public float attackDist;

    Transform currentPatrolPoint;
    int currentPatrolIndex;

    public Transform target;
    public float chaseRange;
    bool chase;
    Rigidbody2D MyRigitbody;
    public HidingSpot hide;
    public Vector3 lastPlayerPos;
    public float detectionRange;

    private AIState state;

    // Use this for initialization
    void Start()
    {
        chase = false;
        currentPatrolIndex = 0;
        currentPatrolPoint = patrolPoints[currentPatrolIndex];
        MyRigitbody = GetComponent<Rigidbody2D>();
        hide = GameObject.FindWithTag("Player").GetComponent<HidingSpot>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 difference = target.position - transform.position;

        RaycastHit2D[] hit = new RaycastHit2D[10];
        if (Physics2D.CircleCastNonAlloc(transform.position, radius, difference.normalized, hit, chaseDist) > 0)
        {
            for (int i = 0; i < hit.Length; i++)
            {
                if (hit[i].collider != null)
                {
                    if (hit[i].collider.tag == "Player")
                    {
                        state = AIState.Chasing;

                    }
                }
            }
        }

        switch (state)
        {
            case AIState.Patrolling:

                break;
            case AIState.Chasing:
                if (Vector2.Distance(target.position, transform.position) < chaseDist)
                {
                    lastPlayerPos = target.position;

                    Vector2 direction = (target.position - transform.position).normalized;
                    MyRigitbody.velocity = Vector2.zero;

                    if (Vector2.Distance(target.position, transform.position) > attackDist)
                    {
                        MyRigitbody.velocity = new Vector2(direction.x, direction.y).normalized * speed;

                    }
                    else if (Vector2.Distance(target.position, transform.position) <= attackDist)
                    {
                        Debug.Log("Attack");
                    }

                    float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90;
                    MyRigitbody.MoveRotation(angle);
                }
                else
                    state = AIState.LostPlayer;
                break;
            case AIState.LostPlayer:
                {
                    Vector2 direction = (currentPatrolPoint.position - transform.position).normalized;

                    MyRigitbody.velocity = new Vector2(direction.x, direction.y).normalized * speed;

                    if (Vector2.Distance(transform.position, currentPatrolPoint.position) < detectionRange)
                    {
                        if (currentPatrolIndex + 1 < patrolPoints.Length)
                        {
                            currentPatrolIndex++;
                        }
                        else
                        {
                            currentPatrolIndex = 0;
                        }
                        currentPatrolPoint = patrolPoints[currentPatrolIndex];

                    }
                    Vector3 patrolPointDir = currentPatrolPoint.position - transform.position;
                    float angel = Mathf.Atan2(patrolPointDir.y, patrolPointDir.x) * Mathf.Rad2Deg - 90f;

                    Quaternion q = Quaternion.AngleAxis(angel, Vector3.forward);
                    transform.rotation = Quaternion.RotateTowards(transform.rotation, q, 180f);
                }
                break;
            default:
                break;
        }



        //Här jagar AI spelaren

        //Här gör vi en raycast som kollar spelarens senaste position och går för att kolla om han fortfarande är där

        //annars går AI tillbaka till att patrulera





    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(transform.position, detectionRange);
    }



    /*
    chase = true;
    float distanceToTarget = Vector2.Distance(transform.position, target.position);
    if (distanceToTarget < chaseRange)
    {
        Vector3 targetDir = target.position - transform.position;
        float angel2 = Mathf.Atan2(targetDir.y, targetDir.x) * Mathf.Rad2Deg - 90f;
        Quaternion q2 = Quaternion.AngleAxis(angel2, Vector3.forward);
        transform.rotation = Quaternion.RotateTowards(transform.rotation, q2, 180f);
        transform.Translate(Vector3.up * Time.deltaTime * speed);

    }
    */
}


