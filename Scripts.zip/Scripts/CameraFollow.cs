﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{

    public Transform PlayerObj;

    [Range(0f, 1f)]
    public float smooth = 0.3f;

    private Vector3 velocity = Vector3.zero;

    void Update()
    {
        Vector3 pos = new Vector3();
        pos.x = PlayerObj.position.x;
        pos.z = PlayerObj.position.z - 10f;
        pos.y = PlayerObj.position.y;
        transform.position = Vector3.SmoothDamp(transform.position, pos, ref velocity, smooth);
        transform.rotation = Quaternion.Euler(Vector3.zero);

    }

}