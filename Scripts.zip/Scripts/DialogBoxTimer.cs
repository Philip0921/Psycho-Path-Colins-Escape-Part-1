﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogBoxTimer : MonoBehaviour
{

    public GameObject box;
    public float MaxTime = 5;
    private float time;

    void Awake()
    {
        StartCoundownTimer();
    }

    void StartCoundownTimer()
    {
        time = MaxTime;
        InvokeRepeating("UpdateTimer", 0.0f, 0.01667f);
    }

    void UpdateTimer()
    {
        if(time > 0)
        time -= Time.deltaTime;

        if (time <= 0 && GameObject.Find("DialogBox(Clone)") == false)
        {
        Instantiate(box, new Vector3(513f, 176f, 0f), transform.rotation);
        time = MaxTime;
        }

        if (time <= 0 && GameObject.Find("DialogBox(Clone)") == true)
        {
            time = MaxTime;
        }
    }
}
