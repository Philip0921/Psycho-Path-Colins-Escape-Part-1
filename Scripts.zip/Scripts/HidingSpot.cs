﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HidingSpot : MonoBehaviour
{
    public GameObject hide;
    public float radius = 0.16f;
    public bool inside = false;

    // Use this for initialization
    void Start()
    {
        hide = gameObject;
    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit2D[] hits = new RaycastHit2D[10];
        if (Physics2D.CircleCastNonAlloc(transform.position, radius, Vector2.zero, hits, 0f) > 0)
        {
            for (int i = 0; i < hits.Length; i++)
            {
                if (Input.GetKeyDown(KeyCode.H))
                {
                    if (hits[i].collider != null)
                    {
                        if (hits[i].collider.GetComponent<Chest>() != null)
                        {
                            inside = true;
                            GetComponent<SpriteRenderer>().enabled = false;
                            GetComponent<MovementPlayer>().enabled = false;
                        }
                        else
                        {
                            print("You can't hide in this object");
                        }
                    }
                }
            }
        }

        if (Input.GetKeyDown(KeyCode.J))
        {
            print("J");
            if (inside)
            {
                print("In");

                GetComponent<SpriteRenderer>().enabled = true;
                GetComponent<MovementPlayer>().enabled = true;
                inside = false;
            }
        }
    }
}
