﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{

    public int health;
    public GameObject heart1;
    public GameObject heart2;
    public GameObject heart3;

    // Use this for initialization
    void Start()
    {
        health = 3;
    }

    // Update is called once per frame
    void Update()
    {
        healthUpdate();

        if (Input.GetKeyDown(KeyCode.B))
            health--;
        if (Input.GetKeyDown(KeyCode.V))
            AddHP();

    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "AI")
        {
            health--;
        }
    }

    void healthUpdate()
    {
        if (health == 3)
        {
            heart3.SetActive(true);
            heart2.SetActive(true);
            heart1.SetActive(true);
        }
        else if (health == 2)
        {
            heart3.SetActive(false);
            heart2.SetActive(true);
            heart1.SetActive(true);
        }
        else if (health == 1)
        {
            heart3.SetActive(false);
            heart2.SetActive(false);
            heart1.SetActive(true);
        }
        else
        {
            heart3.SetActive(false);
            heart2.SetActive(false);
            heart1.SetActive(false);

            SceneManager.LoadScene("GameOver");
        }
    }

    public void AddHP()
    {

        if (health == 3)
            Debug.Log("Health full!");
        else
            health++;

    }
}
