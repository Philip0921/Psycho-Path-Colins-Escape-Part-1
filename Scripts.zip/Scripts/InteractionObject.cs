﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InteractionObject : MonoBehaviour
{
    public void DoInteraction()
    {
        gameObject.SetActive(false);
    }

    public virtual void Interact(Inventory inventory)
    {

    }

    public virtual void Interacting(Chest chestbox)
    {

    }

    public virtual void Use()
    {

    }
}
