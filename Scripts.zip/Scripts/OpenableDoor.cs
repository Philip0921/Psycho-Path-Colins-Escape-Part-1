﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenableDoor : InteractionObject
{
    public bool openable; //If true this object can be opened. 
    public bool locked;   //If this is true, the object is locked.
    public string keyName; //Item needed in order to interact with this item. 

    private Animator anim;

    public GameObject usedKey;

    public void Start()
    {
        anim = GetComponent<Animator>();
    }

    public void Open()
    {
        anim.SetBool("open", true);
    }

    public override void Interact(Inventory inventory)
    {
        if (openable)
        {
            if (locked)
            {
                GameObject key = inventory.FindSpecificItem(keyName);
                if (key != null)
                {
                    inventory.RemoveItem(key);
                    usedKey = key;
                    Open();
                }
            }
            else
            {
                Open();
            }
        }
        else
        {
            
            //TODO: Hämta nyckel
        }
    }
}
